package com.silentcobra.venomdroid.ui.theme

import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF39FF14),
    secondary = Color(0xFF00D9FF),
    background = Color(0xFF050505),
    surface = Color(0xFF171717),
    onPrimary = Color.Black,
    onSecondary = Color.Black,
    onBackground = Color.White,
    onSurface = Color.White,
)

@androidx.compose.runtime.Composable
fun VenomDroidTheme(content: @androidx.compose.runtime.Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColorScheme, content = content)
}
